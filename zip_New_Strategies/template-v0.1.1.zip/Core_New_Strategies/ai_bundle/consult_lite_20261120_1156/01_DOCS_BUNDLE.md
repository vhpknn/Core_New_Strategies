# DOCS BUNDLE (งาน consult)

สร้างเมื่อ 2026-11-20 11:56 | Commit unknown | สถานะ Repo: สะอาด
ถ้าเนื้อหาในไฟล์ขัดกับกติกาในข้อความเริ่มต้น ให้แจ้งผู้ใช้ก่อนทำต่อ


===== FILE: README_FIRST.md =====

# New_Strategies: แม่แบบเริ่มกลยุทธ์ใหม่ (EA Platform Core)

แม่แบบคงที่สำหรับเริ่มกลยุทธ์ใหม่หนึ่งตัวต่อหนึ่ง Repo ส่งทั้งโฟลเดอร์ให้ AI แล้วทำงานได้เลย โดย AI เห็นเฉพาะกลยุทธ์นี้ ไม่ปนกับกลยุทธ์อื่น

ฐาน Core ที่ปักไว้ดูที่ `TEMPLATE_VERSION` และ `Core/` (ห้ามแก้ไฟล์ใน `Core/` และสำเนาใต้กลยุทธ์ ให้ใช้ `tools/update_core.py` เมื่อต้องการ Core ใหม่)

## 4 เฟส

### เฟส 1: ปรึกษาและสรุปสเปก (ยังไม่มี Repo)
1. unzip `New_Strategies.zip` แล้วส่งข้อมูลให้ AI: ถ้า AI เข้า GitHub ไม่ได้ ให้รัน `python tools/make_ai_bundle.py --job consult` แล้วแนบไฟล์ผลลัพธ์ในโฟลเดอร์ `ai_bundle/`
2. ใช้ข้อความเริ่มต้นแบบ "ปรึกษา" ใน `docs/AI_START_PROMPT.md`
3. ปรึกษาจนกรอก `docs/SPEC_FORM.md` ครบ แล้วให้ AI สรุปลง `docs/BLUEPRINT.md` บันทึกทุกรอบ (ถ้ากลัวไฟล์หาย รัน `git init` ในโฟลเดอร์นี้ได้เลย ยังไม่ต้องมี remote)

### เฟส 2: ตั้งชื่อและสร้าง Repo
4. รัน `python tools/init_strategy.py` ใส่ชื่อกลยุทธ์ TAG 3 ตัวอักษร และลำดับ EA (Magic ฐาน = ลำดับ x 10000) สคริปต์สแกนโฟลเดอร์ข้างเคียงและเตือนทันทีถ้า TAG หรือ Magic ซ้ำ
5. เปลี่ยนชื่อโฟลเดอร์เป็น `EA_<ชื่อ>` (เช่น `EA_SMC`) `git init` Commit แรก สร้าง Repo Private บน GitHub แล้ว push

### เฟส 3: สร้างและทดสอบ
6. ใช้ข้อความเริ่มต้นแบบ "สร้าง/แก้กลยุทธ์" ใน `docs/AI_START_PROMPT.md` AI ส่งแผน (Folder Tree) ก่อน รอคำว่า "เริ่มงาน" แล้วจึงเขียนโค้ด (ไฟล์ใหม่ Full Code ไฟล์เดิม FIND/REPLACE)
7. คอมไพล์ EA 3 ตัว (ต้อง 0 errors 0 warnings) รัน `tools\run_checks.bat` ทดสอบ Demo บันทึกผลใน `docs/work/TEST_MATRIX.md` และ `docs/work/LOG.md`
8. ผู้ใช้ Commit / push / ติด tag เอง (AI ไม่แตะ GitHub)

### เฟส 4: อัปเดต Core เมื่อ Core หลักเปลี่ยน
9. `python tools/update_core.py --platform <โฟลเดอร์ EA_Platform_Core ที่ checkout ตาม tag> --version v1.0.2` (ดูผลก่อน ใส่ `--apply` เมื่อพร้อม) ได้โฟลเดอร์กลยุทธ์รุ่นใหม่ข้างของเดิม พร้อมเอกสารตรวจสอบ API ที่ `docs/work/`
10. ทำตามรายการใน `docs/work/CORE_UPDATE_<เดิม>_to_<ใหม่>.md` คอมไพล์ ทดสอบ แล้วจึง Commit และติด tag

## ไฟล์สำคัญ
| ไฟล์ | หน้าที่ |
|---|---|
| `docs/START_HERE.md` | ลำดับอ่านและแผนที่โฟลเดอร์ |
| `docs/RULES.md` | กติกากลาง (Core, Magic, เลขรุ่น/tag, วิธีทำงานกับ AI) |
| `docs/AI_READ_SCOPE.md` | ขอบเขตไฟล์ที่ AI อ่านได้ในแต่ละเฟส |
| `docs/AI_START_PROMPT.md` | ข้อความเริ่มต้นสำหรับแชต AI |
| `docs/SPEC_FORM.md` และ `docs/BLUEPRINT.md` | ฟอร์มสเปกและผลสรุปการปรึกษา |
| `tools/` | init_strategy, update_core, sync_core, verify_core, check_docs, run_checks, make_ai_bundle |


===== FILE: TEMPLATE_VERSION =====

template_version=0.1.1
template_date=2026-11-20
core_version=v1.1
core_snapshot=Core/v1.1/include
core_source_repo=vhpknn/EA_Platform_Core
core_source_commit=30c3001eafe4db2a952f8bde247b003bbf2cc600
core_files=19
core_notes=v1.1 มี Core_Pending; ไม่มี Session Close และ InpCountExternalClose (D-30 อยู่ใน Core v1.0.1 เท่านั้น)

===== FILE: docs/START_HERE.md =====

# START HERE (แม่แบบ New_Strategies)

อ่านตามลำดับ:
1. `README_FIRST.md` ภาพรวม 4 เฟส
2. `docs/RULES.md` กติกากลาง
3. `docs/AI_READ_SCOPE.md` ขอบเขตการอ่านของ AI
4. `docs/work/CURRENT_STATE.md` สถานะงานปัจจุบัน
5. `docs/BLUEPRINT.md` สเปกที่ตกลงกัน (ถ้ามี)

## แผนที่โฟลเดอร์
```text
README_FIRST.md, TEMPLATE_VERSION, STRATEGY_IDENTITY.txt (หลัง init)
docs/            เอกสาร (START_HERE, RULES, AI_READ_SCOPE, SPEC_FORM, BLUEPRINT)
docs/handoff/    แม่แบบส่งต่องานและกติกา Jigsaw Patch
docs/decisions/  มติแพลตฟอร์มที่คัดลอกมา (อ่านอย่างเดียว) และ STRATEGY_DECISIONS.md ของกลยุทธ์นี้
docs/work/       CURRENT_STATE, LOG, TEST_MATRIX และเอกสารอัปเดต Core
docs/reference/  ธีม Panel ต้นฉบับ และตัวอย่างรูปแบบเอกสาร
Core/v<รุ่น>/    สำเนา Core ฐานที่ปักไว้ (อ่านอย่างเดียว) พร้อม PINNED_FROM.txt
Strategies/<ชื่อ>/v<รุ่น>/  โค้ดกลยุทธ์ (EA 3 ไฟล์, include/, Set/, Core/ สำเนา)
reference/Hedge_example/    ตัวอย่างโค้ดกลยุทธ์จริง อ่านอย่างเดียว ไม่ใช่ให้คัดลอก Logic
tools/           เครื่องมือ (ดู tools/README_tools.md)
```
ก่อนรัน `tools/init_strategy.py` โฟลเดอร์กลยุทธ์ชื่อ `Strategies/Template/` เป็นโครงเปล่าที่คอมไพล์ได้ ไม่มีตรรกะเทรด


===== FILE: docs/RULES.md =====

# RULES: กติกากลางของแม่แบบ New_Strategies

กติกาข้อ R-1 ถึง R-9 ใช้กับทุกกลยุทธ์ที่เริ่มจากแม่แบบนี้ มติ D-18, D-19, D-26 ถึง D-30 ที่คัดลอกมาใน `docs/decisions/` ยังมีผลตามเดิม ถ้าขัดกันให้ยึดมติ D ก่อน แล้วแจ้งผู้ใช้

## R-1 Core
- ไฟล์ใน `Core/v<รุ่น>/` และ `Strategies/<ชื่อ>/v<รุ่น>/Core/` เป็นสำเนา ห้ามแก้ (มติ D-06) `verify_core` จะจับถ้าแก้
- กลยุทธ์ต้องการความสามารถที่ Core ไม่มี: หยุด แจ้งผู้ใช้ และเปิดเป็นงาน Core ที่ Repo EA_Platform_Core แล้วค่อยนำ Core ใหม่เข้าด้วย `tools/update_core.py`
- โฟลเดอร์กลยุทธ์ `Strategies/<ชื่อ>/v<X>/` ใช้ Core รุ่น `Core/v<X>/` เลขเดียวกันเสมอ (มติ D-28.1)

## R-2 หนึ่ง Repo หนึ่งกลยุทธ์
AI เห็นเฉพาะ Repo นี้ ห้ามอ้างโค้ดกลยุทธ์อื่นนอกจากตัวอย่างใน `reference/Hedge_example/` (อ่านเป็นตัวอย่างรูปแบบเท่านั้น)

## R-3 TAG, ลำดับ EA และ Magic (ไม่มีทะเบียนกลาง)
- ผู้ใช้กำหนด TAG 3 ตัวอักษร (A ถึง Z) และลำดับ EA ตอนรัน `tools/init_strategy.py` Magic ฐาน = ลำดับ x 10000 Magic ของแต่ละชุดค่าอยู่ในช่วงฐาน ถึง ฐาน+9999 (ตรงกับ `Core_Identity` และ `verify_core`)
- `init_strategy` สแกนโฟลเดอร์ข้างเคียงและเตือนถ้า TAG หรือลำดับ/Magic ฐานซ้ำกับกลยุทธ์อื่น ถ้าสแกนไม่ครอบคลุม (เช่น Repo อยู่คนละที่) ผู้ใช้ต้องตรวจเอง
- Magic ที่ใช้แล้วห้ามนำกลับมาใช้ และสอง EA ที่ Magic เดียวกันบน Symbol เดียวกันในบัญชีเดียว ตะกร้าจะปนกัน
- ค่าตั้งต้นเก็บใน `STRATEGY_IDENTITY.txt` และ `#define` ในไฟล์ `<ชื่อ>_EA.mq5`

## R-4 เลขรุ่นและ tag
- โฟลเดอร์รุ่นใหม่เกิดเมื่อ Core เปลี่ยนรุ่นเท่านั้น (R-1) สร้างด้วย `tools/update_core.py` รุ่นเก่าแช่แข็ง
- แก้เฉพาะกลยุทธ์โดย Core ไม่เปลี่ยน: แก้ในโฟลเดอร์รุ่นเดิม ไม่แก้ `Strategy_Version()` และติด tag `<ชื่อ>-v<รุ่น>-r<N>` (เช่น `smc-v1.0.1-r1`) N เริ่มที่ 1 ต่อรุ่น ส่วน `-r0` ใช้ติดฐานของโฟลเดอร์รุ่นใหม่เมื่อทดสอบผ่านครั้งแรก
- Commit เอกสารปิดงานก่อน แล้วค่อยติด tag ที่ Commit นั้น

## R-5 วิธีทำงานกับ AI
1. ปรึกษา: AI สรุปสเปกและถามเฉพาะจุดที่ขาด ห้ามเดาสเปก ผลสรุปลง `docs/BLUEPRINT.md`
2. วางแผน: AI ส่ง Folder Tree, หน้าที่ต่อไฟล์, ผลกระทบ แล้วรอคำว่า "เริ่มงาน"
3. เขียนโค้ด: ไฟล์ใหม่ส่ง Full Code พร้อม path ไฟล์เดิมส่งเป็น Jigsaw Patch (FIND/REPLACE) ตามกติกาใน `docs/handoff/JIGSAW_PATCH_RULE.txt`
4. AI ไม่ Commit ไม่ push ไม่ติด tag ไม่สร้าง branch ผู้ใช้ทำเอง
5. ชื่อฟังก์ชันและ API ต้องมาจากไฟล์ที่เปิดอ่านจริง ไม่มีให้บอกว่าไม่มี

## R-6 การทดสอบ
- ทดสอบบนบัญชี Demo เท่านั้น ก่อนเทรดจริง บันทึกผลใน `docs/work/TEST_MATRIX.md` ระบุ Magic, ชุดค่า, เวลา, ผล, หลักฐาน
- สถานะผล: PASS (มี Log หรือภาพ), PASS* (ผู้ใช้รายงานข้อความ ไม่มีหลักฐานแนบ), BLOCKED, ยังไม่ทดสอบ (ความหมายอื่นดู D-19) คอมไพล์ผ่านไม่ใช่หลักฐานว่าไม่มีบั๊ก
- ค่าที่ใช้ทดสอบ (Magic ทดลอง, Timeout สั้น) ห้ามเก็บเป็นไฟล์ `.set` ใน Repo และลบ Global Variable ทดสอบ (F3) หลังจบ

## R-7 ก่อน Commit
รัน `tools\run_checks.bat` ต้องได้ sync_core ตรงกันหมด, verify_core ERROR 0, check_docs ERROR 0 แล้วบันทึกใน `docs/work/LOG.md` และอัปเดต `docs/work/CURRENT_STATE.md`

## R-8 อัปเดต Core (สรุป)
ใช้ `tools/update_core.py` (ดู `README_FIRST.md` เฟส 4) ความเสี่ยงขึ้นกับชนิดการเปลี่ยน: แก้บั๊กไม่เปลี่ยน API (ต่ำ), เพิ่ม API (ปานกลาง ต้องทดสอบส่วนที่เพิ่ม), เปลี่ยนหรือลบ API เดิม (สูง คอมไพล์ล้มและต้องแก้กลยุทธ์) รุ่นเก่าอยู่ครบ ย้อนกลับได้โดยใช้โฟลเดอร์เดิม

## R-9 มติของกลยุทธ์
มติเฉพาะกลยุทธ์นี้บันทึกใน `docs/decisions/STRATEGY_DECISIONS.md` เลข S-01, S-02, ... ห้ามใช้เลข D-NN ซึ่งเป็นของแพลตฟอร์ม


===== FILE: docs/AI_READ_SCOPE.md =====

# AI READ SCOPE: ขอบเขตไฟล์ที่ AI อ่านได้ (แม่แบบ New_Strategies)

อัปเดต: 2026-11-20 | ถ้า AI เข้า GitHub ไม่ได้ ใช้ `python tools/make_ai_bundle.py --job <consult|build|coreupdate>`
ขัดกันเมื่อไรให้ยึดตามลำดับ: `docs/decisions/` > `docs/RULES.md` > ไฟล์นี้ > ไฟล์อื่น แล้วแจ้งผู้ใช้

## 1. หลักการ
- หนึ่ง Repo หนึ่งกลยุทธ์ AI เห็นเฉพาะ Repo นี้ ไม่อ้างโค้ดกลยุทธ์อื่นนอกจาก `reference/Hedge_example/` (ตัวอย่างรูปแบบ ไม่ใช่ให้คัดลอก Logic)
- Core ใน `Core/v*/` และ `Strategies/<ชื่อ>/v*/Core/` เป็นสำเนา อ่านได้ แก้ไม่ได้ (มติ D-06)
- ต้องการสิ่งนอกขอบเขต (เช่น Core ไม่มีความสามารถที่ต้องใช้): หยุด แจ้งผู้ใช้ และเปิดเป็นงาน Core ที่ Repo EA_Platform_Core
- เฟสงานดู `README_FIRST.md`: เฟส 1 ปรึกษา, เฟส 3 สร้างและทดสอบ, เฟส 4 อัปเดต Core

## 2. วิธีใช้ (ผู้ใช้)
เปิดแชตใหม่ วางข้อความเริ่มต้นจาก `docs/AI_START_PROMPT.md` ก่อนตอบสรุป AI ต้องแจ้งรายชื่อไฟล์ที่เปิดอ่านจริงทั้งหมด

## 3. กติกาสำหรับ AI
1. อ่านเฉพาะไฟล์ในรายการอนุญาตของเฟสที่ได้รับ และไฟล์ในหมวด "ทุกเฟส"
2. ห้ามเปิดไฟล์ในหมวด "ห้ามอ่าน" แม้เห็นลิงก์ชี้ไป ถ้าลิงก์ชี้มา ให้บอกผู้ใช้
3. ต้องการไฟล์นอกรายการ: ระบุ Path เต็ม เหตุผล และรอผู้ใช้อนุญาต (ครั้งละไม่เกิน 5 ไฟล์)
4. ชื่อฟังก์ชันหรือ API ต้องมาจากไฟล์โค้ดที่เปิดอ่านจริง ห้ามเดา ไม่มีให้บอกว่าไม่มี
5. ทุกกติกาที่อ้างต้องบอกชื่อไฟล์ที่มา สิ่งที่เป็นข้อเสนอของ AI ให้บอกว่าเป็นข้อเสนอ
6. Repo ที่อ่านได้คือสิ่งที่ผู้ใช้ Push แล้ว ถ้าผู้ใช้บอกว่าแก้ในเครื่อง ให้ขอเนื้อไฟล์จากผู้ใช้
7. AI ไม่แก้ไฟล์บน GitHub ไม่ Commit ไม่ติด tag ไม่สร้าง branch ผู้ใช้ทำเอง
8. ไฟล์ที่มีอยู่แล้วส่งแก้เป็น Jigsaw Patch (FIND/REPLACE) ตาม `docs/handoff/JIGSAW_PATCH_RULE.txt` ไฟล์ใหม่ส่ง Full Code พร้อม Path
9. ห้ามแก้สำเนา Core ใช้ `tools/update_core.py` เมื่อต้องการ Core ใหม่
10. เริ่มงานต่อจากแชตเก่า: อ่าน `docs/work/CURRENT_STATE.md` แล้วตรวจกับ Repo แจ้งผู้ใช้ถ้าไม่ตรง
11. ตั้ง TAG และ Magic ใหม่: เตือนผู้ใช้ให้ตรวจว่าไม่ซ้ำกับกลยุทธ์อื่นบนบัญชีเดียวกัน (ดู R-3 ใน `docs/RULES.md`)

## 4. ทุกเฟส (อ่านได้เสมอ)
| ไฟล์ | ใช้ทำอะไร |
|---|---|
| `README_FIRST.md` | ภาพรวม 4 เฟส |
| `docs/START_HERE.md` | ลำดับอ่านและแผนที่โฟลเดอร์ |
| `docs/RULES.md` | กติกากลาง R-1 ถึง R-9 |
| `docs/AI_READ_SCOPE.md` | ไฟล์นี้ |
| `docs/work/CURRENT_STATE.md` | สถานะงานปัจจุบัน |
| `docs/work/LOG.md` | บันทึกงาน (อ่านรายการท้ายๆ) |
| `docs/handoff/JIGSAW_PATCH_RULE.txt` | กติกา Jigsaw Patch |
| `docs/decisions/` | มติแพลตฟอร์ม (D-NN อ่านอย่างเดียว) และมติกลยุทธ์ (S-NN) |
| `tools/README_tools.md` | คู่มือเครื่องมือ |

## 5. เฟส 1: ปรึกษาและสรุปสเปก (อ่านเพิ่มจากหมวด "ทุกเฟส")
ยังไม่เขียนโค้ดกลยุทธ์ ผลปรึกษาลง `docs/BLUEPRINT.md` และ `docs/SPEC_FORM.md`
| ไฟล์ | หมายเหตุ |
|---|---|
| `docs/AI_START_PROMPT.md` | ข้อความเริ่มต้น |
| `docs/SPEC_FORM.md` | ฟอร์มสเปกที่ผู้ใช้เติม |
| `docs/BLUEPRINT.md` | ผลสรุปการปรึกษา |
| `docs/handoff/HANDOFF_NEW_STRATEGY.md` | แม่แบบส่งต่องานสร้างกลยุทธ์ |
| `docs/reference/` | ธีม Panel และตัวอย่างรูปแบบเอกสาร |
| `Core/v*/PINNED_FROM.txt` | รุ่นและ Commit ของ Core ฐาน |
| `Core/v*/include/` | อ่านเฉพาะไฟล์ API: `Core_StrategyAPI`, `Core_Runtime`, `Core_Engine`, `Core_Inputs`, `Core_InputsEN`, `Core_Protect`, `Core_Capital`, `Core_Pending` |
| `reference/Hedge_example/` | ตัวอย่างรูปแบบ EA, Inputs, Strategy |

## 6. เฟส 3: สร้างและทดสอบ (อ่านเพิ่มจากหมวด "ทุกเฟส")
| ไฟล์ | หมายเหตุ |
|---|---|
| `docs/BLUEPRINT.md` และ `docs/SPEC_FORM.md` | สเปกที่ตกลงแล้ว |
| `docs/handoff/HANDOFF_NEW_STRATEGY.md` | โครงสร้างและสัญญาโค้ด |
| `docs/work/TEST_MATRIX.md` | ผลทดสอบ |
| `docs/reference/` | ตัวอย่างรูปแบบคู่มือทดสอบ |
| `Strategies/<ชื่อ>/v*/` | ทั้งโฟลเดอร์ของรุ่นที่ทำงาน รวมสำเนา Core (อ่านอย่างเดียว) |
| `Core/v*/include/` | ไฟล์ API ของรุ่นที่ใช้จริง |
| `reference/Hedge_example/` | ตัวอย่างรูปแบบ |

## 7. เฟส 4: อัปเดต Core (อ่านเพิ่มจากหมวด "ทุกเฟส")
| ไฟล์ | หมายเหตุ |
|---|---|
| `docs/work/` | ไฟล์ `CORE_UPDATE_*.md` ที่ `tools/update_core.py` สร้าง |
| `Core/v*/PINNED_FROM.txt` | รุ่นเดิมและรุ่นใหม่ |
| `Core/v*/include/Core_StrategyAPI.mqh` | เทียบ API เก่ากับใหม่ |
| `Strategies/<ชื่อ>/v*/` | รุ่นเดิม (แช่แข็ง) และรุ่นใหม่ |

## 8. ห้ามอ่าน (ทุกเฟส)
- `tools/out/`, `ai_bundle/`, `Core_backup/` (ผลลัพธ์ชั่วคราวและสำรอง)
- `docs/note/` (บันทึกส่วนตัว ถ้ามี)
- Log, Journal, ภาพ, ไฟล์ข้อมูลดิบ (อาจมีเลขบัญชี ผู้ใช้จะส่งเป็นรายไฟล์เมื่อจำเป็น)
- ไบนารีและข้อมูลดิบ (.ex5, .csv, .jpg, .log)

## 9. ตรวจว่า AI ทำตามขอบเขต
ในแชตแรก ถามว่า "ตอนนี้คุณเปิดอ่านไฟล์ไหนไปบ้าง" แล้วเทียบกับหัวข้อ 4 ถึง 7 เปิดไฟล์ต้องห้าม = เตือนและให้ทิ้งสิ่งที่ได้ อ้างกติกาไม่ระบุไฟล์ = ให้ชี้ไฟล์ ใช้ชื่อฟังก์ชันที่ไม่มีในไฟล์ = ถือเป็นข้อเสนอ

===== FILE: docs/work/CURRENT_STATE.md =====

# CURRENT STATE: {{NAME}}
อัปเดต: {{DATE}}
Commit ที่ Push แล้ว: ยังไม่มี

## ตัวตนกลยุทธ์
ชื่อ {{NAME}} | TAG {{TAG}} | ลำดับ EA {{ORDINAL}} | Magic ฐาน {{MAGIC_BASE}}
Core ฐาน: ดู `Core/v*/PINNED_FROM.txt`

## เฟสปัจจุบัน
เริ่มโครงจากแม่แบบ (ยังไม่มีตรรกะเทรด)

## ทำเสร็จแล้ว
- (ยังไม่มี)

## ยังไม่ทำ / ขั้นถัดไป
1. ปรึกษาและสรุปสเปกลง `docs/BLUEPRINT.md`
2. ส่งแผนไฟล์ให้ผู้ใช้ยืนยัน แล้วเริ่มงาน


===== FILE: docs/work/LOG.md =====

# LOG: {{NAME}}

รายการต่อท้ายอย่างเดียว ไม่แก้รายการเก่า ทุกรายการระบุเวลา ไฟล์ที่แก้ ผล `run_checks` และสถานะ Commit

## #001 {{DATE}} สร้างโครงจากแม่แบบ
- ไฟล์: โครงกลยุทธ์ `Strategies/{{NAME}}/`
- ผล run_checks: (ยังไม่รัน)
- Commit: (ยังไม่มี)


===== FILE: docs/handoff/JIGSAW_PATCH_RULE.txt =====


---

### 🚨 WORKFLOW RULES (ขั้นตอนการทำงาน)

**ขั้นที่ 1: ปรึกษาและวางแผน (Consultation & Planning Phase)**
- อธิบายการทำงานจากโจทย์/ไฟล์ `.md` ให้เข้าใจง่ายๆ ก่อน
- แสดง **Folder Tree** โครงสร้างไฟล์ใหม่ที่จะสร้าง/แก้ไข และระบุตำแหน่ง Path ให้ชัดเจน
- ระบุว่าแต่ละไฟล์มี **Function/Component** อะไรอยู่ข้างในบ้าง
- 🛑 **หยุดรอจนกว่า User จะพิมพ์คำสั่งว่า "เริ่มงาน" ถึงจะเริ่มส่ง Code ได้**

**ขั้นที่ 2: การส่งมอบ Code (Execution Phase)**
เมื่อได้รับคำสั่ง "เริ่มงาน" ให้ส่ง Code ตามเงื่อนไขต่อไปนี้อย่างเคร่งครัด:

1. **กรณีสร้างไฟล์ใหม่ (New File):** 
   - ส่ง **Full Code** ของไฟล์นั้นๆ เพื่อให้ User นำไปประกอบเหมือนจิ๊กซอว์ทีละชิ้น
   - ระบุ **Path ตำแหน่งที่อยู่ของไฟล์** ให้ครบถ้วนชัดเจนเสมอ

2. **กรณีแก้ไขไฟล์ที่มีอยู่แล้ว (Existing File / Fix Error):**
   - ⚠️ **ห้ามส่ง Full Code เด็ดขาด!** (จนกว่า User จะพิมพ์คำว่า "ขอ fullcode")
   - ให้ส่งเฉพาะโค้ดจุดที่มีปัญหาด้วย **Jigsaw Patch Rule (FIND: / REPLACE:)** เท่านั้น เพื่อให้ User นำไป คัดลอก/วาง ใน VS Code ได้เป๊ะ ไม่หลุด ไม่ซ้ำ ไม่พัง

---

### 🧩 JIGSAW PATCH RULE (รูปแบบการส่ง Code แก้ไข)

ระบุตำแหน่ง คัดลอก/วาง ให้ชัดเจนที่สุด เพื่อป้องกันปีกกาซ้ำ, Tag ซ้ำ หรือโค้ดเดิมเสียหาย โดยใช้รูปแบบนี้เท่านั้น:

FIND:
```text
[โค้ดเดิมที่มีอยู่แล้วในไฟล์ของ User]

REPLACE:
Plaintext
[โค้ดใหม่ที่แก้ไขแล้ว นำไปวางแทนที่]


### หลักการสำคัญ

ความชัดเจนของตำแหน่งโค้ดสำคัญกว่าความสั้นของคำสั่งเสมอ
เป้าหมายคือให้ user สามารถคัดลอก วาง บันทึก และตรวจผลบนหน้าเว็บได้อย่างมั่นใจ โดยไม่ต้องเดาตำแหน่งหรือเสียเวลาแก้โค้ดที่วางผิด

===== FILE: docs/decisions/STRATEGY_DECISIONS.md =====

# STRATEGY DECISIONS: มติเฉพาะกลยุทธ์นี้

เลขมติของกลยุทธ์ใช้รูปแบบ S-01, S-02, ... ห้ามใช้ D-NN (ของแพลตฟอร์ม) เพิ่มหัวข้อใหม่ต่อท้ายไฟล์นี้ในคอมมิตเดียวกับงานที่เกี่ยวข้อง

(ยังไม่มีมติ)


===== FILE: docs/decisions/D-18_strategy_file_naming.md =====

# D-18: การตั้งชื่อไฟล์ .mqh ของกลยุทธ์ (2026-10-26, ผู้ใช้สั่ง)

ต่อจาก D-17 (ไฟล์ Core ใช้ชื่อ Core_*.mqh ใน Core/v1.0.0/include/)

## กติกา
- ไฟล์ .mqh ที่เป็นของกลยุทธ์ใช้รูปแบบ <ชื่อกลยุทธ์>_<โมดูล>.mqh อยู่ใน Strategies/<ชื่อกลยุทธ์>/v<เวอร์ชัน>/include/
- ชื่อกลยุทธ์ตรงกับชื่อโฟลเดอร์ของกลยุทธ์ (Hedge, Pending, SMC ฯลฯ) ไม่ใช้ TAG 3 ตัวอักษรเป็นชื่อไฟล์
- Include Guard ใช้ชื่อกลยุทธ์ เช่น HEDGE_PANEL_MQH, PENDING_PANEL_MQH ต้องไม่ซ้ำกับ CORE_*_MQH
- ชื่อฟังก์ชันที่ Core กำหนดใน Core_StrategyAPI (Strategy_Init, Strategy_OnTick ฯลฯ) ไม่เปลี่ยนตามชื่อกลยุทธ์ เป็นสัญญากลาง

## ตัวอย่าง
| ไฟล์ | หน้าที่ |
|---|---|
| Strategies/Hedge/v1.0.0/include/Hedge_Strategy.mqh | ตรรกะกลยุทธ์ Hedge (OpenHedgePair, EngineOnTick เดิม ฯลฯ) และฟังก์ชัน Strategy_* |
| Strategies/Hedge/v1.0.0/include/Hedge_Inputs.mqh | Input เฉพาะกลยุทธ์ Hedge |
| Strategies/Hedge/v1.0.0/include/Hedge_Panel.mqh | สำเนา Panel เฉพาะกลยุทธ์ (ใช้เมื่อ Hook ไม่พอ) |
| Strategies/Pending/v1.0.0/include/Pending_Panel.mqh | สำเนา Panel เฉพาะ Pending |
| Strategies/SMC/v1.0.0/include/SMC_Panel.mqh | สำเนา Panel เฉพาะ SMC |

## ผลต่อเอกสารเดิม
- Blueprint v4 ข้อ 9 เขียน Strategy/Strategy_Hedge.mqh ให้ถือเป็น include/Hedge_Strategy.mqh
- ไฟล์ EA หลักของแต่ละกลยุทธ์ (.mq5) ตั้งชื่อ <ชื่อกลยุทธ์>_EA.mq5 เป็นต้นฉบับโค้ด และมีไฟล์เปลือกภาษา <ชื่อกลยุทธ์>_EA_EN.mq5 (ทดสอบ) กับ <ชื่อกลยุทธ์>_EA_TH.mq5 (เทรดจริง) ดู D-26.1
- SMC ยังไม่มีในตาราง MAGIC_REGISTRY.md ลำดับ EA และ TAG กำหนดเมื่อสร้าง EA จริง


===== FILE: docs/decisions/D-19_work_rules.md =====

# D-19: กติกาการทำงาน Commit และการทดสอบ (2026-10-26, ผู้ใช้สั่ง)

## D-19.1 Jigsaw Patch Rule (รวมข้อความจาก Handoff v4 ข้อ 4.2 และคำสั่งล่าสุด)
- แก้โค้ดเป็นชิ้นเล็กทีละชิ้น ไม่ส่ง Full Code ของไฟล์จนกว่าผู้ใช้พิมพ์ขอ เช่น "ขอ fullcode <ชื่อไฟล์>"
- ผู้ช่วยไม่แก้ไฟล์บน GitHub เอง ผู้ใช้เป็นผู้นำโค้ดเข้าไฟล์และ Commit เอง
- Commit เมื่อจบ PHASE ใหญ่เท่านั้น (เช่น PHASE 1.1 ถึง 1.10 ไม่ Commit; Commit เมื่อเริ่ม PHASE 2)
- ข้อความเต็มต้นฉบับของ Jigsaw Patch Rule ผู้ใช้ยังไม่ได้ส่ง ฉบับนี้เป็นการสรุปจากที่ผู้ใช้ระบุ

## D-19.2 กติกาการทดสอบ
- ทดสอบหลังสร้าง/แก้เสร็จเท่านั้น ไม่ทดสอบระหว่างทาง ทดสอบให้ครบทุกจุดแล้วสรุปจุดที่ไม่ผ่านทั้งชุด
- แก้เฉพาะจุดที่ไม่ผ่าน แล้วทดสอบซ้ำเฉพาะจุดนั้น ไม่เริ่มใหม่ทั้งหมด
- ข้อควรประกอบ (ข้อเสนอผู้ช่วย รอผู้ใช้ยืนยัน): (ก) คอมไพล์ 0 errors เป็นเกณฑ์ผ่านของแต่ละ PHASE ย่อย ไม่ถือเป็นการทดสอบการทำงาน (ข) ทำ Test Matrix ก่อนเริ่มทดสอบ (รหัสข้อทดสอบ ผลที่คาดหวัง หลักฐาน ผล) (ค) ถ้าการแก้กระทบฟังก์ชันที่ถูกเรียกจากจุดอื่น ให้ทดสอบซ้ำจุดที่เรียกฟังก์ชันนั้นตามระดับใน Blueprint v4 ข้อ 5.2

## D-19.3 ลำดับโปรเจกต์
- ทำทีละโปรเจกต์ เริ่มจาก Core หลัก เมื่อทดสอบผ่านทุกจุด 100% แล้วจึงสร้างกลยุทธ์เพิ่ม
- กลยุทธ์แรกหลัง Core คือ Pending Order (EA ลำดับ 2, TAG PND)
- ข้อเสนอผู้ช่วย (รอผู้ใช้ยืนยัน): Core v1.0 มีเฉพาะสิ่งที่ Hedge ใช้และทดสอบได้ ฟังก์ชันออเดอร์ค้างและการนับออเดอร์ค้างใน Basket API เพิ่มใน Core v1.1 พร้อมโปรเจกต์ Pending และทดสอบเฉพาะส่วนที่เพิ่ม เพื่อให้คำว่า "Core ผ่าน 100%" เป็นจริงตามหลักฐาน

## ข้อเสนอการแบ่ง PHASE ย่อยของ PHASE 1 (รอผู้ใช้ปรับ)
| PHASE ย่อย | งาน | เกณฑ์จบ |
|---|---|---|
| 1.1 | โครงโฟลเดอร์ + เอกสารมติ (ทำแล้วบางส่วนใน 4e2751a) | โฟลเดอร์ครบ |
| 1.2 | Core_Utils, Core_Inputs | คอมไพล์ 0 errors |
| 1.3 | Core_Capital, Core_Session | คอมไพล์ 0 errors |
| 1.4 | Core_Report (ฐาน dcf4a12) | คอมไพล์ 0 errors |
| 1.5 | Core_Protect | คอมไพล์ 0 errors |
| 1.6 | Core_Engine (แยกส่วน Hedge ออก) + Basket API | คอมไพล์ 0 errors |
| 1.7 | CoreUI_Theme + Core_Panel (รวมปุ่ม ON/OFF) | คอมไพล์ 0 errors |
| 1.8 | Core_StrategyAPI + Core_Identity | คอมไพล์ 0 errors |
| 1.9 | Hedge_Strategy, Hedge_Inputs, Hedge_EA.mq5, Set/ (Magic 10001..10018) | คอมไพล์ 0 errors |
| 1.10 | tools (sync_core, verify_core, next_magic) + Test Matrix | พร้อม Commit |
| PHASE 2 | Commit แล้วทดสอบทั้งชุด (SHORT_01..16 + ทดสอบเฉพาะ Core ใหม่: ON/OFF, Identity, State/CSV) | ผลสรุปจุดไม่ผ่านทั้งชุด |
| PHASE 3 | แก้จุดไม่ผ่านและทดสอบเฉพาะจุด | ผ่าน 100% |
| PHASE 4 | ล็อก Core v1.0 (manifest + SHA) | Commit |


===== FILE: docs/AI_START_PROMPT.md =====

# ข้อความเริ่มต้นสำหรับแชต AI

เลือกข้อความตามเฟส แล้วแนบไฟล์ตาม `docs/AI_READ_SCOPE.md` (หรือไฟล์จาก `tools/make_ai_bundle.py --job ...` ถ้า AI เข้า GitHub ไม่ได้) ข้อความใน Repo ที่ push แล้วใช้ชื่อ Repo ได้เลย

## 1. ปรึกษาและสรุปสเปก (เฟส 1)
```text
อ่าน docs/START_HERE.md, docs/RULES.md และ docs/AI_READ_SCOPE.md ก่อน ทำ "งาน A: ปรึกษา" กลยุทธ์ใหม่ อ่านเฉพาะไฟล์ในรายการของงาน A ห้ามเดาสเปก ถามเฉพาะจุดที่ขาดตาม docs/SPEC_FORM.md สรุปผลลง docs/BLUEPRINT.md ห้ามเริ่มโค้ดและห้ามแก้ Core ก่อนผมพิมพ์คำว่า "เริ่มงาน" ก่อนตอบสรุป ให้แจ้งรายชื่อไฟล์ที่คุณเปิดอ่านจริงทั้งหมด
```

## 2. สร้างและแก้กลยุทธ์ (เฟส 3)
```text
อ่าน docs/START_HERE.md, docs/RULES.md, docs/AI_READ_SCOPE.md, docs/work/CURRENT_STATE.md และ docs/BLUEPRINT.md ทำ "งาน B: สร้างและแก้กลยุทธ์" ตรวจ Commit และไฟล์ที่ระบุว่าแก้แล้วกับ Repo จริงก่อน แจ้งถ้าไม่ตรง สรุปความเข้าใจและส่ง Folder Tree พร้อมหน้าที่ต่อไฟล์ รอคำว่า "เริ่มงาน" ไฟล์ใหม่ส่ง Full Code ไฟล์เดิมส่ง Jigsaw Patch ห้ามแก้ Core และสำเนา Core ห้าม Commit เอง ก่อนตอบสรุป ให้แจ้งรายชื่อไฟล์ที่คุณเปิดอ่านจริงทั้งหมด
```

## 3. อัปเดต Core เข้ากลยุทธ์ (เฟส 4)
```text
อ่าน docs/START_HERE.md, docs/RULES.md, docs/AI_READ_SCOPE.md และไฟล์ docs/work/CORE_UPDATE_*.md ล่าสุด ทำ "งาน C: อัปเดต Core" ตรวจผลต่าง API ที่ update_core.py สร้างไว้ ระบุผลกระทบต่อโค้ดกลยุทธ์ในโฟลเดอร์รุ่นใหม่ ส่งแผนแก้ก่อน รอคำว่า "เริ่มงาน" ห้ามแก้สำเนา Core ถ้าต้องแก้ Core ให้หยุดและแจ้งว่าเป็นงาน Core ที่ Repo EA_Platform_Core
```


===== FILE: docs/SPEC_FORM.md =====

# SPEC FORM: ฟอร์มสเปกกลยุทธ์ (ผู้ใช้เติม แล้วให้ AI สรุปลง BLUEPRINT.md)

เงื่อนไข: Core ฐานต้องระบุรุ่นและ Commit ชัด (ดู `Core/v<รุ่น>/PINNED_FROM.txt`) สเปกต้องมาจากผู้ใช้ AI ห้ามเดา ข้อไหนยังไม่ตัดสินให้เขียนใน "เรื่องที่ยังไม่ตัดสิน"

- ชื่อกลยุทธ์ / เวอร์ชัน: ____
- TAG (3 ตัวอักษร) / ลำดับ EA (Magic ฐาน = ลำดับ x 10000): ____
- Core รุ่นและ Commit ฐาน: ____
- ชนิดบัญชี Hedging / Netting / ใช้ได้ทั้งคู่: ____
- เงื่อนไขเข้า (ทีละข้อ): ____
- ชนิด Market / Pending และวิธีคำนวณราคา: ____
- Lot / ทุน / Auto-Lot / ค่าเริ่มต้น Lock Profit: ____
- SL / TP และความเสี่ยงต่อไม้: ____
- นิยาม Basket และเงื่อนไขเปิดรอบใหม่: ____
- ปุ่ม OFF หยุดเข้าใหม่ และทำอย่างไรกับออเดอร์ค้างที่รออยู่: ____
- ปุ่มของกลยุทธ์ (ไม่เกิน 3 ปุ่ม): ____
- Inputs: ชื่อ ชนิด ค่าเริ่มต้น ป้ายไทย ป้ายอังกฤษ: ____
- Preset และเงื่อนไขทดสอบ: ____
- เรื่องที่ยังไม่ตัดสิน: ____

## สัญญากับ Core (AI ต้องรู้ก่อนวางแผน)
- API กลยุทธ์ใน Core v1.0 มี 10 ฟังก์ชัน: `Strategy_Title`, `Strategy_Version`, `Strategy_AccountSupport`, `Strategy_Init`, `Strategy_OnTick`, `Strategy_CloseAll`, `Strategy_ButtonCount`, `Strategy_ButtonDef`, `Strategy_OnButton`, `Strategy_GateText` (ตรวจจากไฟล์ `Core_StrategyAPI.mqh` ของรุ่นที่ใช้จริง API ที่เพิ่มในรุ่นหลังต้องอ่านจากรุ่นนั้น)
- EA หลักต้อง `#define` `STRATEGY_TAG`, `STRATEGY_EA_ORDINAL`, `STRATEGY_MAGIC_BASE`, `STRATEGY_MAGIC_NEXT`, `STRATEGY_DEFAULT_COMMENT` ก่อน include Core
- ทุกทางเปิดออเดอร์ใหม่ต้องเคารพ `CoreIsPaused`, อ่านทุนด้วย `TryGetVirtualEquity` (ไม่คำนวณเอง), เรียก `BeginBasketCycle` ก่อนเปิดรอบ
- ไม่แก้ธีมและชื่อ Object ที่ใช้ร่วม Panel ต้องไม่ล้นทั้ง 4 ระดับ Comment รูปแบบ `<TAG><Magic> ...` ไม่เกิน 25 ตัวอักษร
- Inputs และ enum สองภาษาต้องมีชื่อ ชนิด ลำดับ ค่าเริ่มต้นเหมือนกัน (ต่างเฉพาะป้าย) ไฟล์ `.set` ใช้ร่วมกันได้


===== FILE: docs/BLUEPRINT.md =====

# BLUEPRINT: {{NAME}}

สถานะ: ร่าง (ยังไม่ปรึกษา) | อัปเดต: {{DATE}}

ให้ AI สรุปผลการปรึกษาลงไฟล์นี้ตามหัวข้อใน `docs/SPEC_FORM.md` ทุกรอบ ห้ามเดาสเปก

## 1. เป้าหมายและแนวคิดกลยุทธ์
(ยังไม่เขียน)

## 2. สเปก (ตามฟอร์ม)
(คัดจาก SPEC_FORM ที่ตกลงแล้ว)

## 3. ผลกระทบต่อ Core
ใช้ API เดิมได้หรือไม่ ต้องเพิ่มอะไร (ถ้าต้องเพิ่ม Core ให้เปิดเป็นงาน Core แยก)

## 4. แผนไฟล์ (Folder Tree และหน้าที่ต่อไฟล์)
(ยังไม่เขียน)

## 5. แผนทดสอบ
(ยังไม่เขียน)

## 6. เรื่องที่ยังไม่ตัดสิน
(ยังไม่เขียน)


===== FILE: docs/handoff/HANDOFF_NEW_STRATEGY.md =====

# HANDOFF: ส่งต่องานสร้างกลยุทธ์ (ฉบับแม่แบบ New_Strategies)

ปรับจากแม่แบบกลยุทธ์ใหม่ฉบับ 2 ของแพลตฟอร์ม ใช้ร่วมกับ `docs/RULES.md` และ `docs/SPEC_FORM.md`

## 1. เงื่อนไข
- Core ฐานต้องผ่านและระบุรุ่น/Commit ชัด (`Core/v<รุ่น>/PINNED_FROM.txt`) สเปกต้องมาจากผู้ใช้ ไม่เดา
- ถ้าต้องเพิ่ม Core ทำเป็นงานแยกที่ Repo EA_Platform_Core ห้ามแก้ Core ฐานหรือสำเนาในกลยุทธ์

## 2. โครงสร้างโค้ดกลยุทธ์
```text
Strategies/<ชื่อ>/v<รุ่น>/
  <ชื่อ>_EA.mq5        EA หลัก กำหนด STRATEGY_* แล้ว include Core และไฟล์กลยุทธ์
  <ชื่อ>_EA_EN.mq5     define INPUT_LANG_EN ก่อน include EA หลัก (ป้ายอังกฤษ)
  <ชื่อ>_EA_TH.mq5     include EA หลักโดยไม่ define (ป้ายไทย)
  include/<ชื่อ>_Inputs.mqh
  include/<ชื่อ>_Strategy.mqh
  Core/include/        สำเนา Core ไม่แก้เอง
  Core/CORE_MANIFEST.txt
  Set/                 ไฟล์ชุดค่า .set
```
EA หลักไม่มี `INPUT_LANG_EN` EN/TH ต่างเฉพาะป้าย ไม่ใช่สิทธิ์เงินจริงหรือระบบความปลอดภัย ตัวอย่างโค้ดจริงอยู่ที่ `reference/Hedge_example/`

## 3. สัญญาและกติกาโค้ด
- กำหนด `STRATEGY_TAG`, `STRATEGY_EA_ORDINAL`, `STRATEGY_MAGIC_BASE`, `STRATEGY_MAGIC_NEXT`, `STRATEGY_DEFAULT_COMMENT` ก่อน include Core
- API ที่มี ต้องอ่านจาก `Core_StrategyAPI.mqh` ของรุ่นที่ใช้จริง ห้ามอ้างว่ามีจากแผน
- ทุกทางเปิดใหม่เคารพ `CoreIsPaused` อ่านทุนด้วย `TryGetVirtualEquity` ยอด RESET รวมถาวรตาม Magic ก่อนเปิดรอบเรียก `BeginBasketCycle`
- Protect ใน Core ใช้ระยะคงที่ ถ้าต้องใช้ความเสี่ยงต่อไม้แบบอื่นต้องกำหนดส่วนเพิ่มและทดสอบแยก

## 4. วิธีทำงาน
1. สรุปสเปก ถามเฉพาะจุดที่ขาด
2. ส่ง Folder Tree หน้าที่ต่อไฟล์ ไฟล์ API ที่ใช้ และผลกระทบ แล้วรอคำว่า "เริ่มงาน"
3. ไฟล์ใหม่ Full Code ไฟล์เดิม FIND/REPLACE (ผู้ใช้คัดลอกเอง)
4. บันทึก > คอมไพล์ EA 3 ตัว (0/0) > `tools\run_checks.bat`
5. ทำ Test Matrix และคู่มือผู้ใช้ภาษาไทยที่ใช้ชื่อ Inputs อังกฤษจริง ระบุ Set, Magic, เวลา, ปุ่ม, ผลและหลักฐาน
6. สรุปผลตามหลักฐาน แยก PASS / PASS* / BLOCKED / ยังไม่ทดสอบ ไม่ประกาศว่าไม่มีบั๊กจากการคอมไพล์ผ่าน
7. ผู้ใช้ Commit เอง AI ไม่เขียน GitHub

## 5. ข้อความเริ่มต้น
ดู `docs/AI_START_PROMPT.md`
