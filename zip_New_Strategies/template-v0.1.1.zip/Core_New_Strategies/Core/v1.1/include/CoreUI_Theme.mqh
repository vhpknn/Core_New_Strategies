//+------------------------------------------------------------------+
//|                                                CoreUI_Theme.mqh  |
//|  UI_THEME: CORE_DARK_NEON_V1                                     |
//|  Dark Trading Dashboard Theme for MetaTrader 5 EA Panels         |
//|  ที่มา: HedgeUI_Theme.mqh เปลี่ยนเฉพาะชื่อ (ไม่เปลี่ยนค่า)         |
//+------------------------------------------------------------------+
#ifndef CORE_UI_THEME_MQH
#define CORE_UI_THEME_MQH

//====================================================================
// 1. FONT STANDARD
//====================================================================

//--- Font หลักของ Panel ทั้งหมด
#define CUI_FONT "Arial Bold"

//--- ขนาด Font: Normal Mode
#define CUI_FONT_HEADER       10
#define CUI_FONT_NORMAL       9
#define CUI_FONT_IMPORTANT    10
#define CUI_FONT_BUTTON       9
#define CUI_FONT_FOOTER       9

//--- ขนาด Font: Compact Mode
#define CUI_FONT_HEADER_C     9
#define CUI_FONT_NORMAL_C     8
#define CUI_FONT_IMPORTANT_C  9
#define CUI_FONT_BUTTON_C     8
#define CUI_FONT_FOOTER_C     8

//====================================================================
// 2. PANEL COLORS
//====================================================================

//--- พื้นหลังและขอบ
#define CUI_BG        C'18,18,18'      // #121212 พื้นหลัง Dark
#define CUI_BORDER    C'51,51,51'      // #333333 ขอบ Panel
#define CUI_HEADER    C'255,215,0'     // #FFD700 Header / Footer ทอง
#define CUI_TEXT      clrWhite         // สีขาวสำหรับค่าปกติ/ค่า 0
#define CUI_LABEL     C'225,225,225'   // Label ทั่วไป ขาวอมเทาสว่าง

//====================================================================
// 3. STATUS / FINANCIAL COLORS
//====================================================================

//--- ค่าสำคัญ
#define CUI_CYAN      C'0,255,255'     // Effective Lot
#define CUI_GREEN     C'0,255,125'     // Equity / Profit / ON / OPEN
#define CUI_RED       C'255,85,75'     // Loss / OFF / BLOCK
#define CUI_YELLOW    C'255,215,0'     // Active Position > 0

//--- จำนวน Position แยกตามฝั่ง
#define CUI_BUY_TEXT  C'80,165,255'    // Buy > 0
#define CUI_SELL_TEXT C'255,95,90'     // Sell > 0

//====================================================================
// 4. BUTTON COLORS
//====================================================================

//--- ปุ่มเปิด Buy
#define CUI_BTN_BUY          C'30,86,160'    // #1E56A0
#define CUI_FRAME_BUY        C'30,86,160'

//--- ปุ่มเปิด Sell
#define CUI_BTN_SELL         C'217,83,79'    // #D9534F
#define CUI_FRAME_SELL       C'217,83,79'

//--- ปุ่ม Close Buy: น้ำเงินเข้ม + กรอบฟ้าสว่าง
#define CUI_BTN_CLOSE_BUY    C'18,55,96'
#define CUI_FRAME_CLOSE_BUY  C'53,135,235'

//--- ปุ่ม Close Sell: แดงเข้ม + กรอบแดงสว่าง
#define CUI_BTN_CLOSE_SELL   C'112,38,42'
#define CUI_FRAME_CLOSE_SELL C'245,92,86'

//--- ปุ่ม Refill
#define CUI_BTN_REFILL       C'64,64,64'
#define CUI_FRAME_REFILL     C'51,51,51'

//--- ปุ่ม Hedge Open
#define CUI_BTN_HEDGE        C'106,27,154'
#define CUI_FRAME_HEDGE      C'106,27,154'

//--- ปุ่ม Close All
#define CUI_BTN_CLOSE_ALL    C'184,134,11'
#define CUI_FRAME_CLOSE_ALL  C'51,51,51'

//====================================================================
// 5. PANEL DIMENSIONS
//====================================================================

//--- Normal Mode
#define CUI_PANEL_X          8
#define CUI_PANEL_Y          28
#define CUI_PANEL_W_NORMAL   430
#define CUI_PANEL_H_NORMAL   360
#define CUI_PANEL_H_MIN      36

//--- Responsive Breakpoints
#define CUI_PANEL_COMPACT_AT 520
#define CUI_PANEL_MIN_AT     330

//--- ขนาดกรอบหนารอบปุ่ม CLOSE BUY / CLOSE SELL
#define CUI_CLOSE_FRAME_PAD  3

//====================================================================
// 6. PANEL RULES (COMMENT FOR FUTURE DEVELOPERS)
//====================================================================

/*
UI_THEME: CORE_DARK_NEON_V1 (LOCKED)

FONT:
- ใช้ Arial Bold ทุก Label และ Button
- Header 10 px / Normal 9 px / Important 10 px
- Compact ลดลงเล็กน้อย แต่ต้องอ่านง่าย

COLOR RULES:
- Positive Value = CUI_GREEN
- Negative Value = CUI_RED
- Zero / Neutral = CUI_TEXT
- Effective Lot = CUI_CYAN
- Virtual Equity = CUI_GREEN เมื่อ > 0, CUI_RED เมื่อ <= 0
- Closed Net = CUI_GREEN เมื่อ > 0, CUI_RED เมื่อ < 0, CUI_TEXT เมื่อ = 0
- Open Floating = CUI_GREEN เมื่อ > 0, CUI_RED เมื่อ < 0, CUI_TEXT เมื่อ = 0
- Cycle Loss = CUI_RED เมื่อ < 0, CUI_TEXT เมื่อ = 0

POSITION COLOR RULES:
- Active > 0 = CUI_YELLOW
- Active = 0 = CUI_TEXT
- Buy > 0 = CUI_BUY_TEXT
- Buy = 0 = CUI_TEXT
- Sell > 0 = CUI_SELL_TEXT
- Sell = 0 = CUI_TEXT

STATUS COLOR RULES:
- Session OPEN = CUI_GREEN ทั้งแถว
- Session BLOCK/CLOSE = CUI_RED ทั้งแถว
- Spread Check ON = CUI_GREEN ทั้งแถว
- Spread Check OFF = CUI_RED ทั้งแถว
- Timeout ON = CUI_GREEN ทั้งแถว
- Timeout OFF = CUI_RED ทั้งแถว

BUTTON RULES:
- BUY = น้ำเงิน
- SELL = แดง
- CLOSE BUY = น้ำเงินเข้ม + กรอบฟ้าหนาขนาด CUI_CLOSE_FRAME_PAD
- CLOSE SELL = แดงเข้ม + กรอบแดงหนาขนาด CUI_CLOSE_FRAME_PAD
- REFILL = เทา
- HEDGE OPEN = ม่วง
- CLOSE ALL = มัสตาร์ด

LAYOUT:
- Normal: 430 x 360 px
- Compact: เมื่อความกว้างกราฟ < 520 px
- Auto Minimize: เมื่อความกว้างกราฟ < 330 px
- Footer อยู่ด้านขวาใต้ปุ่ม CLOSE ALL
- Panel ต้องมีปุ่ม - / + สำหรับ Minimize
*/

#endif // CORE_UI_THEME_MQH